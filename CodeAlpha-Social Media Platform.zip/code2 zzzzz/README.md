# Mini Social Media Platform

A simple social media app built with Express.js backend and HTML/CSS/JS frontend.

## Features

- User registration and login
- User profiles
- Create posts
- Like posts
- Comment on posts
- Like comments
- Follow/unfollow users

## Setup

1. Install MongoDB and start it on localhost:27017
2. Navigate to backend folder: `cd backend`
3. Install dependencies: `npm install`
4. Start the server: `npm start`
5. Open frontend/index.html in browser or serve it.

## API Endpoints

- POST /api/users/register
- POST /api/users/login
- GET /api/users/:id
- POST /api/posts
- GET /api/posts
- PUT /api/posts/:id/like
- POST /api/comments
- GET /api/comments/:postId
- PUT /api/comments/:id/like
- PUT /api/follows/:id/follow
- PUT /api/follows/:id/unfollow

## Technologies

- Backend: Express.js, MongoDB, Mongoose
- Frontend: HTML, CSS, JavaScript