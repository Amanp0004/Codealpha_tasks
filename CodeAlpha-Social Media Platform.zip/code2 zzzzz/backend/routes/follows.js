const express = require('express');
const User = require('../models/User');

const router = express.Router();

// Follow user
router.put('/:id/follow', async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    const currentUser = await User.findById(req.body.userId);
    if (!user.followers.includes(req.body.userId)) {
      user.followers.push(req.body.userId);
      currentUser.following.push(req.params.id);
      await user.save();
      await currentUser.save();
    }
    res.json({ message: 'Followed' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Unfollow user
router.put('/:id/unfollow', async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    const currentUser = await User.findById(req.body.userId);
    user.followers = user.followers.filter(id => id.toString() !== req.body.userId);
    currentUser.following = currentUser.following.filter(id => id.toString() !== req.params.id);
    await user.save();
    await currentUser.save();
    res.json({ message: 'Unfollowed' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

module.exports = router;