const API_BASE = 'http://localhost:5000/api';

let token = localStorage.getItem('token');
let userId = localStorage.getItem('userId');

// Auth
document.getElementById('register').addEventListener('click', async () => {
  const username = document.getElementById('username').value;
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  const res = await fetch(`${API_BASE}/users/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, email, password })
  });
  const data = await res.json();
  alert(data.message);
});

document.getElementById('login').addEventListener('click', async () => {
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  const res = await fetch(`${API_BASE}/users/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password })
  });
  const data = await res.json();
  if (data.token) {
    token = data.token;
    localStorage.setItem('token', token);
    // Assume userId from token, but for simplicity, fetch user
    // For now, set userId manually or decode token
    alert('Logged in');
    loadPosts();
  } else {
    alert(data.error);
  }
});

// Posts
document.getElementById('create-post').addEventListener('click', async () => {
  const content = document.getElementById('post-content').value;
  const res = await fetch(`${API_BASE}/posts`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
    body: JSON.stringify({ user: userId, content })
  });
  if (res.ok) {
    document.getElementById('post-content').value = '';
    loadPosts();
  }
});

async function loadPosts() {
  const res = await fetch(`${API_BASE}/posts`);
  const posts = await res.json();
  const feed = document.getElementById('feed');
  feed.innerHTML = '';
  posts.forEach(post => {
    const postEl = document.createElement('div');
    postEl.className = 'post';
    postEl.innerHTML = `
      <p><strong>${post.user.username}</strong>: ${post.content}</p>
      <button onclick="likePost('${post._id}')">Like (${post.likes.length})</button>
      <button onclick="showComments('${post._id}')">Comments</button>
      <div id="comments-${post._id}"></div>
      <textarea id="comment-content-${post._id}" placeholder="Add comment"></textarea>
      <button onclick="addComment('${post._id}')">Comment</button>
    `;
    feed.appendChild(postEl);
  });
}

async function likePost(postId) {
  await fetch(`${API_BASE}/posts/${postId}/like`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId })
  });
  loadPosts();
}

async function showComments(postId) {
  const res = await fetch(`${API_BASE}/comments/${postId}`);
  const comments = await res.json();
  const commentsEl = document.getElementById(`comments-${postId}`);
  commentsEl.innerHTML = '';
  comments.forEach(comment => {
    const commentEl = document.createElement('div');
    commentEl.className = 'comment';
    commentEl.innerHTML = `<p><strong>${comment.user.username}</strong>: ${comment.content}</p>
    <button onclick="likeComment('${comment._id}')">Like (${comment.likes.length})</button>`;
    commentsEl.appendChild(commentEl);
  });
}

async function addComment(postId) {
  const content = document.getElementById(`comment-content-${postId}`).value;
  await fetch(`${API_BASE}/comments`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ user: userId, post: postId, content })
  });
  showComments(postId);
}

async function likeComment(commentId) {
  await fetch(`${API_BASE}/comments/${commentId}/like`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId })
  });
  // Reload comments, but need postId
}

// On load
if (token) {
  loadPosts();
}